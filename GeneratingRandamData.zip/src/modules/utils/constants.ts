import path from "path";
import { env } from "process";


export const ROOT_FOLDER:string = process.cwd();
export const CONFIG_FOLDER:string = path.join(ROOT_FOLDER, "config");
export const EMAIL_TEMPLATES_FOLDER:string = path.join(ROOT_FOLDER, "email-templates");
export const PROGRAM_FILE_NAME:string = env.PROGRAM_FILE_NAME || "programs.json";

export const ccmDataID:string="ccmDataID";

export const PROSPIFI_PROGRAMS:any= {
    FILE_IMPORT:'prospifi-fileimport',
    CASS_NCOA:'prospifi-cassncoa',
    SUPPRESSION: 'prospifi-suppression',
    DEDUP:'prospifi-dedup',
    PREVIOUS_MAIL_DROP:'prospifi-previous-mail-drop',
    NON_PII:'prospifi-Non-PII',
    RETURN_FILE:'prospifi-return-file',
    FINAL_FILE:'prospifi-final-file'
};

export const SATORI_INPUT_FIELD_TYPES:any = {
   firstName: "firstname",
   lastName: "lastname",
   businessName: "businessname",
   address: "address",
   address2 : "address2",
   city: "city",
   state: "state",
   zip: "zip",
   customnumericimb: "customnumericimb"
};

export const  SUPPRESS_INPUT_FIELD_TYPES:any={
   SSN:"SSN",
   LastName:"LName",
   Address:"Address",
   City:"city",
   State:"state",
   Zip:"zip"
}


export const DATA_SOURCE_TYPES:any = {
   UNC: "unc",
   FTP: "ftp",
   SFTP: "sftp"
};

export const FILE_EXT_TYPES:any = {
   json: "json",
   csv: "csv",
   xml: "xml"
};


export const NON_PII_INPUT_FIELD_TYPES:any = {
   TU_MATCH_KEY: "TU_Match_Key",
   STATE:'State',
   ZIP: "ZipCode",
   CAMPAIGN_TYPE: "CampType",
   CAMPAIGN_DATA_TYPE: "CampDataType"
};

export const MATCH_KEY_INPUT_FIELD_TYPES:any = {
   TU_MATCH_KEY: "TU_Match_Key"
};

export const PROSPIFI_PROVIDERS:any= {
   TU:'TU',
   EXPERIAN:'Experian',
 
}

export const NOTIFICATION_TYPES:any = {
   FTP_CONNECTION_FAIL: "FTP Connection Fail",
   SFTP_CONNECTION_FAIL: "SFTP Connection Fail"
};

export const EMAIL_TEMPLATE_TYPES:any = {
   DATA_SOURCE_CONNECTION_FAIL_TEMPLATE: "datasource-connection-error-notification.html",
};