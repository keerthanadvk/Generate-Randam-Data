import  logger  from "../utils/logtrace";

export class Retrier {
    private actionTitle: string;
    private func: () => Promise<any>;
    private totalRetries: number;
    private secondsMultiplier: number;

    constructor(actionTitle: string, func: () => Promise<any>, options: { totalRetries?: number; secondsMultiplier?: number } = {}) {
        this.actionTitle = actionTitle || "";
        this.func = func;
        this.totalRetries = options.totalRetries || 3;
        this.secondsMultiplier = options.secondsMultiplier || 5;
    }

    async attempt(retryCount: number = 1): Promise<any> {
        try {
            const result = await this.func();
            return result;
        } catch (err) {
            logger.error(err.message || err);
            if (retryCount >= this.totalRetries) {
                logger.error(`${this.actionTitle} attempt ${retryCount} / ${this.totalRetries} failed. Giving up!`);
                throw err;
            }

            const seconds = retryCount * this.secondsMultiplier;
            logger.error(`${this.actionTitle} attempt ${retryCount} / ${this.totalRetries} failed. Retrying in ${seconds} seconds!`);
            await this._wait(seconds);
            return this.attempt(retryCount + 1);
        }
    }

    private async _wait(seconds: number): Promise<void> {
        return new Promise(resolve => {
            const ms = seconds * 1000;
            setTimeout(resolve, ms);
        });
    }
}



