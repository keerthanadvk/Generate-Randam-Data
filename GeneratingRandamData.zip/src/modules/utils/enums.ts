

export enum  SuppressMatchStatus{
    SSN_MATCHED="Suppressed SSN-Matched",
    LAST_NAME_ADDRESS_MATCHED="Suppressed LastName_Address-Matched",
    ADDRESS_MATCHED="Suppressed Address-Matched",
    SINGLE_SUPPRESSION_MATCHED="Suppressed Single Supression-Matched",
    WORD_SUPPRESSION_MATCHED="Suppressed Word-Matched",
}


export enum  EnrichmentTypeEnums{
    cass="cass",
    geocoding="geocoding",
    ncoa="ncoa"
   
}