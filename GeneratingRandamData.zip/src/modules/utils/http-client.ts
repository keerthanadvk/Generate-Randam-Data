import * as request from "request";
import { promisify } from "util";

type PromisifiedRequestMethod = (uri: string | request.OptionsWithUri, options?: request.CoreOptions | null) => Promise<request.Response>;

const promisifiedRequest: Record<string, PromisifiedRequestMethod> = {
    get: promisify(request.get) as PromisifiedRequestMethod,
    put: promisify(request.put) as PromisifiedRequestMethod,
    post: promisify(request.post) as PromisifiedRequestMethod,
    patch: promisify(request.patch) as PromisifiedRequestMethod,
    delete: promisify(request.delete) as PromisifiedRequestMethod
};

export default promisifiedRequest;