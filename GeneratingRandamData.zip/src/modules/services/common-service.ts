const className = "CommonService";
import logger from "../../modules/utils/logtrace";
import path from 'path';
import { PROGRAM_FILE_NAME, CONFIG_FOLDER, FILE_EXT_TYPES } from "../utils/constants";
const fs = require('fs');
const xmlParser = require("xml2json");
const json2xml = require("json2xml");
const csvtojson = require('csvtojson');
import { parse } from 'json2csv';
const SftpClient = require("ssh2-sftp-client");
const sftp = new SftpClient();
export class CommonService {
    async readJSONFile(filePath: string) {
        const methodName = "readJSONFile";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        return new Promise<any>(resolve => {
            let jsonDataResult;
            try {
                if (filePath != undefined && filePath != '') {
                    if (fs.existsSync(filePath)) {
                        const fileName = path.basename(filePath);
                        //let fileWithOutExtention = fileName.split('.')[0];
                        const fileExtention = path.extname(fileName);

                        if (fileExtention.toLowerCase() == ".json") {
                            jsonDataResult = JSON.parse(fs.readFileSync(filePath));
                            //logger.info(`Class - ${className} :: method - ${methodName} jsonDataResult Data = \n ${JSON.stringify(jsonDataResult, null, "\t")}`);
                            resolve(jsonDataResult);
                        }
                    }
                    else {
                        logger.info(`Class - ${className} :: method - ${methodName} Invalid file Path - ${filePath}`);
                    }
                }
                else {
                    logger.info(`Class - ${className} :: method - ${methodName} json file path empty`);
                }
            }
            catch (err) {
                logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
            }
            logger.info(`Class - ${className} method - ${methodName} End`);
        });
    }


    _convertXmlToJson(xmlData: string) {
        const methodName = "_convertXmlToJson";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        let result: any;
        try {
            result = JSON.parse(xmlParser.toJson(xmlData, {
                object: false,
                reversible: false,
                coerce: false,
                sanitize: true,
                trim: true,
                arrayNotation: false,
                alternateTextNode: false
            }));
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
            return undefined;
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return result;
    }

    getProgramByProgramName(programs: any, programname: string) {
        const methodName = "getProgramByProgramName";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            if (programname) {
                programs = Array.isArray(programs) ? programs : [programs];
                if (programs.length > 0) {
                    return programs.find((program: any) => {
                        return program.programname.toLowerCase().trim() == programname.toLowerCase().trim();
                    });
                }
            }
            else
                return undefined;
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
    }
    

    convertCsv2Json(csvfilePath: string) {
        const methodName = "convertCsv2Json";
        logger.info(`Class - ${className} method - ${methodName} Begin`);

        let jsonDataResult: any = [];
        try {
            if (csvfilePath != undefined && csvfilePath != '') {
                if (fs.existsSync(csvfilePath)) {
                    const fileName = path.basename(csvfilePath);
                    //let fileWithOutExtention = fileName.split('.')[0];
                    const fileExtention = path.extname(fileName);

                    if (fileExtention.toLowerCase() == ".csv") {
                        jsonDataResult = csvtojson().fromFile(csvfilePath);
                        //logger.info(`Class - ${className} :: method - ${methodName} jsonDataResult Data length = \n ${jsonDataResult.length}`);
                        //logger.info(`Class - ${className} :: method - ${methodName} jsonDataResult Data = \n ${JSON.stringify(jsonDataResult, null, "\t")}`);
                        return jsonDataResult;
                    }
                }
                else {
                    logger.info(`Class - ${className} :: method - ${methodName} No Such FIle Found -${csvfilePath}`);
                }
            }
            else {
                logger.info(`Class - ${className} :: method - ${methodName} csv file path empty`);
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
    }

    convertJsontoCsv(jsonData: string) {
        const methodName = "convertJsontoCsv";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            if (jsonData.length > 0) {
                const csvdata = parse(jsonData);
                return csvdata;
            }
            else {
                logger.info(`Class - ${className} :: method - ${methodName} json empty`);
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return undefined;
    }


    saveCSVFile(jsonData: string, filePath: string) {
        const methodName = "saveCSVFile";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            if (jsonData.length > 0) {

                const csvData = this.convertJsontoCsv(jsonData);
                fs.writeFileSync(filePath, csvData, 'utf8');
                return true;
            }
            else {
                logger.info(`Class - ${className} :: method - ${methodName} json empty`);
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);

        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return false;
    }

    saveJSONFile(jsonData: string, filePath: string) {
        const methodName = "saveCSVFile";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            if (jsonData.length > 0) {
                
                fs.writeFileSync(filePath, JSON.stringify(jsonData,null,2), 'utf8');
                return true;
            }
            else {
                logger.info(`Class - ${className} :: method - ${methodName} json empty`);
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);

        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return false;
    }

    _convertJsonToXMl(jsonData: any) {
        return json2xml(jsonData, {
            header: true
        });
    }

    async getPrograms() {
        return await this.readJSONFile(path.join(CONFIG_FOLDER, PROGRAM_FILE_NAME));
    }

    async getFilesFromDirectory(directoryPath: string) {
        const methodName = "getFilesFromDirectory";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            if (!fs.existsSync(directoryPath)) {
                logger.info(`Class - ${className} method - ${methodName} directory not exist`);
                return [];
            }
            let files = fs.readdirSync(directoryPath);
            files = files.map((fileName: string) => {
                return path.join(directoryPath, fileName)
            });
            return [].concat(files);

        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return [];
    }


    async connectSFTP(host: string, port: number, username: string, password: string) {
        const methodName = "connectSFTP";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        const sftpInfo: any = { sftpConnected: false, sftp: null };
        try {
            logger.info(`Class - ${className} method - ${methodName} sftp host : ${host}, port : ${port}, username : ${username}, password : ${password} `);
            await sftp.connect({
                host: host,
                port: port,
                username: username,
                password: password
            });

            logger.info(`Class - ${className} method - ${methodName} SFTP Connected Successfully`);
            sftpInfo.sftpConnected = true;
            sftpInfo.sftp = sftp;
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
            sftpInfo.sftpConnected = false;
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return sftpInfo;
    }


    async getFilesFromSFTP(sftp: any, remotePath: string) {
        const methodName = "getFilesFromSFTP";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            logger.info(`Class - ${className} method - ${methodName} sftp remotePath : ${remotePath} `);
            if (sftp.exists(remotePath)) {
                const files = await sftp.list(remotePath);
                logger.info(`Class - ${className} method - ${methodName} files count : ${files.length} `);
                return files;
            }
            else {
                logger.info(`Class - ${className} method - ${methodName} sftp remotePath not exist : ${remotePath} `);
                return [];
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);

        }
        logger.info(`Class - ${className} method - ${methodName} End`);
    }

    async UploadFileToSFTP(sftp: any, localFile:string,remoteFile: string) {
        const methodName = "UploadFileToSFTP";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
                await  sftp.fastPut(localFile, remoteFile);
                logger.info(`Class - ${className} method - ${methodName} File Uploaded`);
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);

        }
        logger.info(`Class - ${className} method - ${methodName} End`);
    }



    async validateFileByRegularExp(file: string, filePatternRegExp: string) {
        const methodName = "validateFileByRegularExp";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            logger.info(`Class - ${className} method - ${methodName} file: ${file} `);
            logger.info(`Class - ${className} method - ${methodName} reguExp: ${filePatternRegExp} `);
            if (filePatternRegExp != undefined && filePatternRegExp != '' && filePatternRegExp != null)
            {
                const isValid = new RegExp(filePatternRegExp).test(file);
                if (isValid === true)
                    return true;
            }
           
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);

        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return false;
    }

    async downloadFileFromSFTP(sftp: any, sourceFilePath: string,destinationFilePath:string) {
        const methodName = "downloadFileFromSFTP";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            logger.info(`Class - ${className} method - ${methodName} sourceFilePath : ${sourceFilePath} `);
            logger.info(`Class - ${className} method - ${methodName} destinationFilePath : ${destinationFilePath} `);
            if (await sftp.exists(sourceFilePath)) {
                await sftp.get(sourceFilePath, destinationFilePath);
                logger.info(`Class - ${className} method - ${methodName} file Downloaded `);
                return true;
            }
            else {
                logger.info(`Class - ${className} method - ${methodName} file not exist : ${sourceFilePath} `);
                return false;
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);

        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return false;
    }

    async deleteFileFromSFTP(sftp: any, sourceFilePath: string) {
        const methodName = "deleteFileFromSFTP";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            logger.info(`Class - ${className} method - ${methodName} sourceFilePath : ${sourceFilePath} `);
            if (sftp.exists(sourceFilePath)) {
                await sftp.delete(sourceFilePath);
                logger.info(`Class - ${className} method - ${methodName} file deleted `);
                return true;
            }
            else {
                logger.info(`Class - ${className} method - ${methodName} file not exist : ${sourceFilePath} `);
                return false;
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);

        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return false;
    }

    async getFileRecordsCount(filePath: any) {
        const methodName = "getFileRecordsCount";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        const fileRecordsCount=0;
        try {
            const fileExtention = path.extname(filePath);
                switch (fileExtention.toLowerCase()) {
                    case ".txt":
                    case ".csv":
                        return  await this.getTextFileRecordsCount(filePath);
                    default:
                        break;
            }
            
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return fileRecordsCount;
    }

    async getTextFileRecordsCount(filePath: any) {
        const methodName = "getTextFileRecordsCount";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        let fileRecordsCount=0;
        try {
            logger.info(`Class - ${className} method - ${methodName} filePath = ${filePath}`);
            if (fs.existsSync(filePath)) {
                const content = fs.readFileSync(filePath,"utf8");
                fileRecordsCount = content.split("\n").length - 1;
                return fileRecordsCount;
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return fileRecordsCount;
    }

    async splitFile(filePath: string,splitCount:number) {
        const methodName = "splitFile";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        let splitFileDetails:any={};
        try {
            const fileExtention = path.extname(filePath);
                switch (fileExtention.toLowerCase()) {
                    case ".txt":
                    case ".csv":
                        splitFileDetails=  await this.splitTextFile(filePath,splitCount);
                        return splitFileDetails;
                    default:
                        break;
            }
            
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return splitFileDetails;
    }

    async splitTextFile(filePath: string,splitCount:number) {
        const methodName = "splitTextFile";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        const splitFIleDetails:any={splitFiles:[],splitFilesCount:0};
        try {
            logger.info(`Class - ${className} method - ${methodName} filePath = ${filePath}`);
            if (fs.existsSync(filePath)) {
                const fileName = path.basename(filePath);
                const fileNameWithOutExtention = fileName.split('.')[0];
                const fileExtention = path.extname(fileName);
                logger.info(`Class - ${className} method - ${methodName} fileNameWithOutExtention = ${fileNameWithOutExtention}`);
                logger.info(`Class - ${className} method - ${methodName} fileExtention = ${fileExtention}`);

                const content = fs.readFileSync(filePath, "utf8");
                const lines = content.trim().split("\n");
                let count = 0;
                while (lines.length > 0) {
                    const DataContent = lines.splice(0, splitCount).join("\n");
                    count++;
                   const countstr= count.toString().padStart(2, "0");

                    const splitFileName = `${fileNameWithOutExtention}_${countstr}`;
                   const splitFilePath = filePath.replace(fileNameWithOutExtention,splitFileName);
          
                    fs.writeFileSync(splitFilePath, DataContent);
                    splitFIleDetails.splitFiles.push(splitFilePath);

                  }
                  splitFIleDetails.splitFilesCount=count;
                  return splitFIleDetails;
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return splitFIleDetails;
    }


    async getFileData(file: any, fileType:string) {
        const methodName = "getFileData";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {
            switch (fileType.toLowerCase()) {
                case FILE_EXT_TYPES.json.toLowerCase():
                    return await this.readJSONFile(file);
                case FILE_EXT_TYPES.csv.toLowerCase():
                    return this.convertCsv2Json(file);
                default:
                    break;
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return [];
    }
    
    getValidFile(filePath: string, fileNameFormat:string) {
        const methodName = "getValidFile";
        logger.info(`Class - ${className} method - ${methodName} Begin`);
        try {

            const fileName = path.basename(filePath);
            const fileNameWithOutExtention = fileName.split('.')[0];
            const fileExtention = path.extname(fileName);
            if (fileExtention==path.extname(fileNameFormat)) {
                const replacedFileName = fileNameWithOutExtention;
                if (fileNameWithOutExtention == replacedFileName && fileNameFormat.includes(replacedFileName))
                    return filePath;
            }
        }
        catch (err) {
            logger.error(`Error :: Class - ${className} method - ${methodName}`, err);
        }
        logger.info(`Class - ${className} method - ${methodName} End`);
        return undefined;

    }
}