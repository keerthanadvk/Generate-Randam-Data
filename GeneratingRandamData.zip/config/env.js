exports.PORT=4200;
exports.DB_CONNECTION=`postgres://postgres:Postgres@321@localhost:5432/LSMailShop`;
exports.PROGRAM_FILE_NAME='programs.json'
exports.NCOA_CHUNK_SIZE=2500

//Satori service keys
exports.SATORI_URL='http://mailroomservicesfull.accuconnect.com';
exports.SATORI_AUTHOTIZATION=`Basic YWRtaW46dGVzdA==`;
exports.SATORI_CLIENT_ID= 'QCOMS-TEST',
exports.SATORI_CAPS_CUSTOMER_ID='605_4065634',
exports.SATORI_LIST_PROCESSOR ='admin',
exports.SATORI_MAILER_NAME ='tecra',
exports.SATORI_MAILER_ADDRESS ='#suite 123',
exports.SATORI_MAILER_CITY ='Farmington Hills',
exports.SATORI_MAILER_STATE ='Michigan',
exports.SATORI_MAILER_ZIP ='48335',
exports.SATORI_MAILER_COUNTRY ='US',
exports.SATORI_MAILDAT_JOB_ID ='',
exports.SATORI_LOGIN_BROKER_ID ='TAL6VR',
exports.SATORI_LOGIN_BROKER_PWD ='6A6A9BHD',
exports.SATORI_LOGIN_CUSTOMER_ID ='K9ZCU5',
exports.SATORI_LOGIN_CUSTOMER_PWD ='H47INUD1',
exports.SATORI_STORE_ID  =''




//Job Intervals keys Start

exports.watchFileImportInterval=1; //seconds
exports.watchCassNCOAInterval=1; //seconds
exports.watchSuppressionInterval=1; //seconds
exports.watchDeDupInterval=1; //seconds
exports.watchPreviousMailDropInterval=1; //seconds
exports.watchNonPIIInterval=1; //seconds
exports.watchReturnFileInterval=1;//seconds
exports.watchFinalFileInterval=1;//seconds

//Job Intervals keys Start



//SMTP KEYS start
exports.SMTP_MAIL_SERVICE=`zoho`;
exports.SMTP_HOST_ADDRESS=`smtp.zoho.com`;
exports.SMTP_PORT=587
exports.SMTP_FROM_MAIL=`xxxx@tecra.com`
exports.SMTP_USER_NAME=`xxxx@tecra.com`
exports.SMTP_USER_PASSWORD=`xxxxxx`
exports.BCC_MAILS=`rajasekhar.mannava@tecra.com`
exports.SUPPORT_MAILS=`balasurendra.vattiprolu@tecra.com`
exports.NOTIFY_MAILS='allabakash.dadabaigari@tecra.com'

//SMTP KEYS end

exports.MERGE_NONPII=true
exports.NONPII_FileName='prospifi_nonpii.csv'
exports.PROGRAM_FILE_NAME = 'programs.json'

